% generate the unit square domain and pass it back
function [T,f,uD,exEnergyNormSq] = create_domain_unitSquare()

	% geometry: the unit square
	T=struct();
	T.coords = [0,0;1,0;1,1;0,1];
	T.elems = [2,4,1;4,2,3];
	T.dirichlet = [1,2;2,3;3,4;4,1];
	T.neumann = [];
	T=refine(T);

	% right-hand side f
	f = @(x) -ones(size(x,1),1);

	% Dirichlet data
	uD = @(x) zeros(size(x,1),1);

	% exact solution
	exEnergyNormSq = 0.0351442537;

end
