function [x,S,M,C,ndof] = P1FEM_convDiff(T,f,uD,beta,epsilon)

N=size(T.coords,1); % number of vertices
S=sparse(N,N);  % stiffness matrix
M=sparse(N,N);  % mass matrix
C=sparse(N,N);  % convection matrix

% assemble stiffness, mass, and convection matrices
for j=1:size(T.elems,1)
    area=abs(det([ones(1,3);T.coords(T.elems(j,:),:)'])/2);
    grads=[ones(1,3);T.coords(T.elems(j,:),:)']\[zeros(1,2);eye(2)];
    S(T.elems(j,:),T.elems(j,:))=...
        S(T.elems(j,:),T.elems(j,:))+area*(grads*grads');
    M(T.elems(j,:),T.elems(j,:))=...
        M(T.elems(j,:),T.elems(j,:))+area/12*(ones(3)+eye(3));
    % now the convection matrix
    C(T.elems(j,:),T.elems(j,:))=...
        C(T.elems(j,:),T.elems(j,:))+(area/3*repmat(grads*beta,1,3));
    
    
end 

% assemble right-hand side and solve the linear system
x=zeros(N,1);
dirNodes = unique(T.dirichlet(:));
x(dirNodes) = uD(T.coords(dirNodes,:));

b = M*f(T.coords) - (epsilon*S+C)*x;
A = epsilon*S+C;
% solve the linear system Ax = b
freeNodes=setdiff(1:N,dirNodes);
ndof=length(freeNodes);
x(freeNodes)=A(freeNodes,freeNodes)\b(freeNodes);


end
