
function main

nRefinements = 3;

% Use the unit square
[T,f,uD,exEnergyNormSq] = create_domain_unitSquare;
% or use the L-shaped domain
%[T,f,uD,exEnergyNormSq] = create_domain_Lshaped;


%Execute the program
ndofList=zeros(nRefinements,1);
errEnergyList=zeros(nRefinements,1);

epsilon=0.01;
beta=[1;0];

    
r1 = (-1 + sqrt(1+4*epsilon^2*pi^2))/(-2*epsilon);
r2 = (-1 - sqrt(1+4*epsilon^2*pi^2))/(-2*epsilon);

% right-hand side f
c1= exp(-r1)-exp(-r2);

for j = 1:nRefinements
    % refine the mesh
    T=refine(T);
    % compute discrete solution for the poisson equation
    %[x,S,M,ndof] = P1FEM_poisson(T,f,uD);
    % or compute the discrete solution for the convection-diffusion
    % equation

f = @(x) ...
    [((r1*exp(r1*(x(:,1)-1))- r2*exp(r2*(x(:,1)-1)))/c1+1).*sin(pi*x(:,2)),...
         ((exp(r1*(x(:,1)-1))- exp(r2*(x(:,1)-1)))/c1+x(:,1)-1).*(pi*cos(pi*x(:,2)))]...
      *beta ...
    - epsilon*...
     ( (r1^2*exp(r1*(x(:,1)-1))- r2^2*exp(r2*(x(:,1)-1)))/c1.*sin(pi*x(:,2))...
         - ((exp(r1*(x(:,1)-1))- exp(r2*(x(:,1)-1)))/c1+x(:,1)-1).*(pi^2*sin(pi*x(:,2))));

    [x,S,M,C,ndof] = P1FEM_convDiff(T,f,uD,beta,epsilon);
    
    % compute the error
    ndofList(j)=ndof;
    % Strange. In the case of the L-Shaped domain, the error gets imaginary
    errEnergyList(j) = sqrt(exEnergyNormSq-x'*S*x);
end

% display the discrete solution
figure
trisurf(T.elems,T.coords(:,1),T.coords(:,2),x)
title(strcat('Discrete solution, ndof=',num2str(ndof)))

% display convergence history

exSol = @(x) ((exp(r1*(x(:,1)-1))- exp(r2*(x(:,1)-1)))/(exp(-r1)-exp(-r2))+x(:,1)-1).*sin(pi*x(:,2));
figure;
trisurf(T.elems,T.coords(:,1),T.coords(:,2),exSol(T.coords));
title(strcat('Ex. sol'));

figure
loglog(ndofList,errEnergyList,'-x')
xlabel('ndof')
legend('u-u_h energy norm')
title('convergence history')

end