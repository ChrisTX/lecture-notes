function exampleCD

nRefinements = 4;

% geometry: the unit square
T=struct();
T.coords = [0,0;1,0;1,1;0,1];
T.elems = [2,4,1;4,2,3];
T.dirichlet = [1,2;2,3;3,4;4,1];
T.neumann = [];
T=refine(T);

beta=[1;0];
epsilon = 0.0001;

r1 = (-1 + sqrt(1+4*epsilon^2*pi^2))/(-2*epsilon);
r2 = (-1 - sqrt(1+4*epsilon^2*pi^2))/(-2*epsilon);

% right-hand side f
c1= exp(-r1)-exp(-r2);
f = @(x) ...
    [((r1*exp(r1*(x(:,1)-1))- r2*exp(r2*(x(:,1)-1)))/c1+1).*sin(pi*x(:,2)),...
         ((exp(r1*(x(:,1)-1))- exp(r2*(x(:,1)-1)))/c1+x(:,1)-1).*(pi*cos(pi*x(:,2)))]...
      *beta ...
    - epsilon*...
     ( (r1^2*exp(r1*(x(:,1)-1))- r2^2*exp(r2*(x(:,1)-1)))/c1.*sin(pi*x(:,2))...
         - ((exp(r1*(x(:,1)-1))- exp(r2*(x(:,1)-1)))/c1+x(:,1)-1).*(pi^2*sin(pi*x(:,2))));

% Dirichlet data
uD = @(x) zeros(size(x,1),1);



% exact solution
exSol = @(x) ((exp(r1*(x(:,1)-1))- exp(r2*(x(:,1)-1)))/(exp(-r1)-exp(-r2))+x(:,1)-1).*sin(pi*x(:,2));

ndofList=zeros(nRefinements,1);

errEnergyList=zeros(nRefinements,1);

for j = 1:nRefinements
    % refine the mesh
    T=refine(T);
    % compute discrete solution
    [x,S,M,C,ndof] = ConvDiff(T,f,uD,epsilon,beta);
    % compute the error
    ndofList(j)=ndof;
    e = x - exSol(T.coords);
    errEnergyList(j) = sqrt(e'*S*e);
end

% display the discrete solution
figure
trisurf(T.elems,T.coords(:,1),T.coords(:,2),x)
title(strcat('Discrete solution, ndof=',num2str(ndof)))

% display the exact solution
figure
trisurf(T.elems,T.coords(:,1),T.coords(:,2),exSol(T.coords))
title('exact solution')

% display convergence history
figure
loglog(ndofList,errEnergyList,'-x')
xlabel('ndof')
legend('u-u_h energy norm')
title('convergence history')

end