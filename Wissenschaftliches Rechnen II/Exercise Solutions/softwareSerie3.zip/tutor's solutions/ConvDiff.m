function [x,S,M,C,ndof] = ConvDiff(T,f,uD,epsilon,beta)


N=size(T.coords,1); % number of vertices
S=sparse(N,N);  % stiffness matrix
M=sparse(N,N);
C=sparse(N,N);
% assemble stiffness and mass matrices
for j=1:size(T.elems,1)
    area=abs(det([ones(1,3);T.coords(T.elems(j,:),:)'])/2);
    grads=[ones(1,3);T.coords(T.elems(j,:),:)']\[zeros(1,2);eye(2)];
    S(T.elems(j,:),T.elems(j,:))=...
        S(T.elems(j,:),T.elems(j,:))+area*(grads*grads');
    C(T.elems(j,:),T.elems(j,:))=...
        C(T.elems(j,:),T.elems(j,:))+area/3* repmat((grads*beta)',3,1);
    M(T.elems(j,:),T.elems(j,:))=...
        M(T.elems(j,:),T.elems(j,:))+area/12*(ones(3)+eye(3));
end

% assemble right-hand side and solve the linear system
x=zeros(N,1);
dirNodes = unique(T.dirichlet(:));
x(dirNodes) = uD(T.coords(dirNodes,:));
b = M*f(T.coords) - (epsilon*S+C)*x;
% solve the linear system
freeNodes=setdiff(1:N,dirNodes);
ndof=length(freeNodes);
x(freeNodes)=(epsilon*S(freeNodes,freeNodes)+C(freeNodes,freeNodes))\b(freeNodes);
end

