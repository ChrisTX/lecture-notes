
% generate the L-shaped domain and pass it back
function [T,f,uD,exEnergyNormSq] = create_domain_Lshaped()

    % geometry: L shaped domain
    T = struct();
    T.coords = [-1,-1;0,-1;0,0;-1,0;0,1;-1,1;1,0;1,1];
    T.elems = [1,2,3;1,3,4;4,3,5;4,5,6;3,7,8;3,8,5];
    T.dirichlet = [1,2;2,3;3,7;7,8;8,5;5,6;6,4;4,1];
    T.neumann = [];
    T=refine(T);

    % right-hand side f
    f = @(x) -ones(size(x,1),1);

    % Dirichlet data
    uD = @(x) zeros(size(x,1),1);

    % exact solution
    exEnergyNormSq = 0.0351442537; 
    
end

