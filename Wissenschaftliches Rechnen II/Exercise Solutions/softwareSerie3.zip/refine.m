function Tnew = refine(T)
%% refineUniformRed - Refine every element the "red" way.
%   refineUniformRed(c4n, n4e, n4sDb, n4sNb) Refines a given mesh uniformly
%       using the red refinement. For details on data structures and
%       refinement strategies see the documentation. Input is a mesh
%       defined by c4n, n4e, n4sDb and n4sNb. Output is a refined mesh
%       defined by c4nNew, n4eNew, n4sDbNew and n4sNbNew.

c4n = T.coords;
n4e = T.elems;
n4sDb = T.dirichlet;
n4sNb = T.neumann;
    %% Preliminary work.
    nrNodes = size(c4n,1);
    nrElems = size(n4e,1);
    n4s = computeN4s(n4e);
    nrSides = size(n4s,1);
    newNodes4s = sparse(n4s(:,1),n4s(:,2),(1:nrSides)'+ nrNodes, ...
                        nrNodes,nrNodes);
    newNodes4s = newNodes4s + newNodes4s';

    %% Compute coordinates for new nodes.
    % As every element is refined "red", there is a new node on each side.
    mid4s = computeMid4s(c4n,n4s);
    c4nNew = [c4n;mid4s];

    %% red refinement
    n4eNew = zeros(4*nrElems,3);
    for curElem = 1 : nrElems
        curNodes = n4e(curElem,:);
        curNewNodes = [newNodes4s(curNodes(1),curNodes(2));
                       newNodes4s(curNodes(2),curNodes(3));
                       newNodes4s(curNodes(3),curNodes(1));
                      ];
        % Generate new elements.
        n4eNew(4*(curElem-1)+1:4*curElem,:) = ...
                  [ curNodes(1)    curNewNodes(1) curNewNodes(3);
                    curNewNodes(1) curNodes(2)    curNewNodes(2);
                    curNewNodes(2) curNewNodes(3) curNewNodes(1);
                    curNewNodes(3) curNewNodes(2) curNodes(3);
                  ];  
    end
   
    %% refinement of  Dirichlet boundary
    n4sDbNew = zeros(2*size(n4sDb,1),2);
    for curSide = 1 : size(n4sDb,1)
        curNodes = n4sDb(curSide,:);
        curNewNodes = newNodes4s(curNodes(1),curNodes(2));
        % Generate new Dirichlet boundary sides.
        n4sDbNew(2*(curSide-1)+1:2*curSide,:) = ...
                  [ curNodes(1)    curNewNodes;
                    curNewNodes    curNodes(2);
                  ];  
    end

    %% refinement of  Neumann boundary
    n4sNbNew = zeros(2*size(n4sNb,1),2);
    for curSide = 1 : size(n4sNb,1)
        curNodes = n4sNb(curSide,:);
        curNewNodes = newNodes4s(curNodes(1),curNodes(2));
        % Generate new Neumann boundary sides.
        n4sNbNew(2*(curSide-1)+1:2*curSide,:) = ...
                  [ curNodes(1)    curNewNodes;
                    curNewNodes    curNodes(2);
                  ];  
    end
    
    
Tnew = struct();
Tnew.coords = c4nNew;
Tnew.elems = n4eNew;
Tnew.dirichlet = n4sDbNew;
Tnew.neumann = n4sNbNew;
end


function n4s = computeN4s(n4e)
%% computeN4s - Nodes for sides.
%   computeN4s(n4e) returns a matrix in which each row corresponds to one side 
%               of the decomposition. The side numbering is the same as in
%               e4s, s4n, s4e, length4s, mp4s, normal4s and tangent4s. Each
%               row consists of the numbers of the end nodes of the 
%               corresponding side. n4e is as specified in the 
%               documentation.
%
%   See also: computeE4s, computeS4n, computeS4e, computeLength4s,
%             computeMid4s, computeNormal4s, computeTangent4s

    if isempty(n4e)
        n4s = [];
        return;
    end

    %% Compute n4s.
    % Gather a list of all sides including duplicates (occurring for inner
    % sides), then sort each row and make sure the rows are unique, thus
    % eliminating duplicates.
    allSides = [n4e(:,[1 2]); n4e(:,[2 3]); n4e(:,[3 1])];
    % Eliminate duplicates, remember original index of remaining rows.
    [b,ind] = unique(sort(allSides,2),'rows','first');
    n4s = allSides(sort(ind),:);
end

function mid4s = computeMid4s(c4n, n4s)
%% computeMid4s - midpoints for sides.
%   computeMid4s(c4n, n4s) computes the midpoint for each side of the
%                     decomposition. c4n and n4s are as specified in the
%                     documentation.
%
%   See also: computeN4s, computeMid4e
    
    if isempty(n4s)
        mid4s = zeros(0,2);
        return;
    end

    %% Compute mid4s.
    mid4s = 0.5 * ( c4n(n4s(:,1),:) + c4n(n4s(:,2),:) );
end